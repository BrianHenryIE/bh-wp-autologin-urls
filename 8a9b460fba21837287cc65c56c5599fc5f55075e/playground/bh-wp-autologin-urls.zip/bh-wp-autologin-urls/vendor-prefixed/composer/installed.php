<?php return array (
  'root' => 
  array (
    'name' => 'brianhenryie/bh-wp-autologin-urls',
    'pretty_version' => 'dev-8a9b460fba21837287cc65c56c5599fc5f55075e',
    'version' => 'dev-8a9b460fba21837287cc65c56c5599fc5f55075e',
    'reference' => '8a9b460fba21837287cc65c56c5599fc5f55075e',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'beberlei/assert' => 
    array (
      'pretty_version' => 'v3.3.4',
      'version' => '3.3.4.0',
      'reference' => 'f193f4613c7d7fbcee2c05e4daff4061d49c040e',
      'type' => 'library',
      'install_path' => __DIR__ . '/../beberlei/assert',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wc-logger' => 
    array (
      'pretty_version' => '0.2',
      'version' => '0.2.0.0',
      'reference' => 'c2288a5c9a4a59a0890f5c09f06d260381b1c78f',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wc-logger',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-logger' => 
    array (
      'pretty_version' => '0.3.4',
      'version' => '0.3.4.0',
      'reference' => '9cc96dc64ca3b5c436f7574e3bd00e917d133791',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-logger',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-private-uploads' => 
    array (
      'pretty_version' => '0.4.0',
      'version' => '0.4.0.0',
      'reference' => 'eb02977d6162f3468222b62c5678da84d6a4cb16',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-private-uploads',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-rate-limiter' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'reference' => '201c073bff978f74b1583bb7165bf5e2fdc11d24',
      'type' => 'wordpress-library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-rate-limiter',
      'aliases' => 
      array (
        0 => '9999999-dev',
      ),
      'dev_requirement' => false,
    ),
    'guzzlehttp/guzzle' => 
    array (
      'pretty_version' => '7.15.2',
      'version' => '7.15.2.0',
      'reference' => '744101956d78b7c1384d0cbf379db13e859167bf',
      'type' => 'library',
      'install_path' => __DIR__ . '/../guzzlehttp/guzzle',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'guzzlehttp/promises' => 
    array (
      'pretty_version' => '2.5.1',
      'version' => '2.5.1.0',
      'reference' => '9ad1e4fc607446a055b95870c7f668e93b5cff29',
      'type' => 'library',
      'install_path' => __DIR__ . '/../guzzlehttp/promises',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'guzzlehttp/psr7' => 
    array (
      'pretty_version' => '2.13.0',
      'version' => '2.13.0.0',
      'reference' => 'dad89620b7a6edb60c15858442eb2e408b45d8f4',
      'type' => 'library',
      'install_path' => __DIR__ . '/../guzzlehttp/psr7',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'klaviyo/sdk' => 
    array (
      'pretty_version' => '1.0.3.20220329',
      'version' => '1.0.3.20220329',
      'reference' => 'f277387007c7a84765e4b12802de6c18c7865fa5',
      'type' => 'library',
      'install_path' => __DIR__ . '/../klaviyo/sdk',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'monolog/monolog' => 
    array (
      'pretty_version' => '3.10.0',
      'version' => '3.10.0.0',
      'reference' => 'b321dd6749f0bf7189444158a3ce785cc16d69b0',
      'type' => 'library',
      'install_path' => __DIR__ . '/../monolog/monolog',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'nikolaposa/rate-limit' => 
    array (
      'pretty_version' => '3.3.0',
      'version' => '3.3.0.0',
      'reference' => '5a1d8b245d67a7526d8af649c17520b7161f0d6c',
      'type' => 'library',
      'install_path' => __DIR__ . '/../nikolaposa/rate-limit',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-client' => 
    array (
      'pretty_version' => '1.0.3',
      'version' => '1.0.3.0',
      'reference' => 'bb5906edc1c324c9a05aa0873d40117941e5fa90',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-client',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-factory' => 
    array (
      'pretty_version' => '1.1.0',
      'version' => '1.1.0.0',
      'reference' => '2b4765fddfe3b508ac62f829e852b1501d3f6e8a',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-factory',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-message' => 
    array (
      'pretty_version' => '2.0',
      'version' => '2.0.0.0',
      'reference' => '402d35bcb92c70c026d1a6a9883f06b2ead23d71',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-message',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/log' => 
    array (
      'pretty_version' => '3.0.2',
      'version' => '3.0.2.0',
      'reference' => 'f16e1d5863e37f8d8c2a01719f5b34baa2b714d3',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/log',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/simple-cache' => 
    array (
      'pretty_version' => '1.0.1',
      'version' => '1.0.1.0',
      'reference' => '408d5eafb83c57f6365a3ca330ff23aa4a5fa39b',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/simple-cache',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'ralouphie/getallheaders' => 
    array (
      'pretty_version' => '3.0.3',
      'version' => '3.0.3.0',
      'reference' => '120b605dfeb996808c31b6477290a714d356e822',
      'type' => 'library',
      'install_path' => __DIR__ . '/../ralouphie/getallheaders',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/deprecation-contracts' => 
    array (
      'pretty_version' => 'v3.7.1',
      'version' => '3.7.1.0',
      'reference' => 'f3202fa1b5097b0af062dc978b32ecf63404e31d',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/deprecation-contracts',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'wp-oop/transient-cache' => 
    array (
      'pretty_version' => 'v0.2.0-alpha1',
      'version' => '0.2.0.0-alpha1',
      'reference' => '774783e36637ddf1682f85649d9ccef8e455df25',
      'type' => 'library',
      'install_path' => __DIR__ . '/../wp-oop/transient-cache',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'wptrt/admin-notices' => 
    array (
      'pretty_version' => 'v1.0.4',
      'version' => '1.0.4.0',
      'reference' => '1df860950b4198cc93e867873b1b571b51f908b0',
      'type' => 'library',
      'install_path' => __DIR__ . '/../wptrt/admin-notices',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);