<?php
/**
 * Handle AJAX requests from the log table page (or custom settings page).
 *
 * @package brianhenryie/bh-wp-logger
 */

namespace BrianHenryIE\WP_Autologin_URLs\WP_Logger\Admin;

use BrianHenryIE\WP_Autologin_URLs\WP_Logger\API_Interface;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\Logger_Settings_Interface;

/**
 * Handle delete and delete-all actions.
 *
 * @uses API_Interface::delete_log()
 * @uses API_Interface::delete_all_logs()
 * @uses Logger_Settings_Interface::get_plugin_slug()
 */
class AJAX {

	/**
	 * AJAX constructor.
	 *
	 * @param API_Interface             $api Implementation of the plugin's main functions.
	 * @param Logger_Settings_Interface $settings The current settings for the logger / Settings describing the plugin this logger is for.
	 */
	public function __construct(
		protected API_Interface $api,
		protected Logger_Settings_Interface $settings
	) {
	}

	/**
	 * Delete a single log file.
	 *
	 * Request body should contain:
	 * * `action` "bh_wp_logger_logs_delete_all".
	 * * `date_to_delete` in `Y-m-d` format, e.g. 2022-03-02.
	 * * `plugin_slug` containing the slug used in settings.
	 * * `_wpnonce` with action `bh-wp-logger-delete`.
	 *
	 * Response format will be:
	 * array{success: bool, message: ?string}.
	 *
	 * @hooked wp_ajax_bh_wp_logger_logs_delete
	 *
	 * @uses API_Interface::delete_log()
	 */
	public function delete(): void {

		if ( ! isset( $_POST['_wpnonce'], $_POST['plugin_slug'], $_POST['date_to_delete'] )
			|| ! is_string( $_POST['_wpnonce'] ) || ! is_string( $_POST['plugin_slug'] ) || ! is_string( $_POST['date_to_delete'] )
			|| ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'bh-wp-logger-delete' )
		) {
			return;
		}

		// bh-wp-logger could be hooked for many plugins.
		if ( $this->settings->get_plugin_slug() !== sanitize_key( $_POST['plugin_slug'] ) ) {
			return;
		}

		$ymd_date = sanitize_key( $_POST['date_to_delete'] );

		$result = $this->api->delete_log( $ymd_date );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * Delete all log files for this plugin.
	 *
	 * Request body should contain:
	 * * `action` "bh_wp_logger_logs_delete".
	 * * `plugin_slug` containing the slug used in settings.
	 * * `_wpnonce` with action "bh-wp-logger-delete".
	 *
	 * Response format will be:
	 * array{success: bool, message: ?string}.
	 *
	 * @hooked wp_ajax_bh_wp_logger_logs_delete_all
	 *
	 * @uses API_Interface::delete_all_logs()
	 */
	public function delete_all(): void {

		if ( ! isset( $_POST['_wpnonce'], $_POST['plugin_slug'] )
			|| ! is_string( $_POST['_wpnonce'] ) || ! is_string( $_POST['plugin_slug'] )
			|| ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'bh-wp-logger-delete' )
		) {
			return;
		}

		// bh-wp-logger could be hooked for many plugins.
		if ( $this->settings->get_plugin_slug() !== sanitize_key( $_POST['plugin_slug'] ) ) {
			return;
		}

		$result = $this->api->delete_all_logs();

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
}
