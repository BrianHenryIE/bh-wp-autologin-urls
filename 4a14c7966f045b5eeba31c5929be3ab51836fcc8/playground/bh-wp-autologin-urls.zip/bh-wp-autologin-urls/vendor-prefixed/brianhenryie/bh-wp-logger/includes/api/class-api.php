<?php
/**
 * The main functions of the logger.
 *
 * @package brianhenryie/bh-wp-logger
 */

namespace BrianHenryIE\WP_Autologin_URLs\WP_Logger\API;

use BrianHenryIE\WP_Autologin_URLs\WC_Logger\WC_PSR_Logger;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\Admin\Logs_List_Table;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\Admin\Logs_Page;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\API_Interface;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\Logger_Settings_Interface;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\Logger;
use BrianHenryIE\WP_Autologin_URLs\WP_Logger\WooCommerce_Logger_Settings_Interface;
use DateTime;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Exception;
use BrianHenryIE\WP_Autologin_URLs\Psr\Log\LoggerAwareTrait;
use BrianHenryIE\WP_Autologin_URLs\Psr\Log\LoggerInterface;
use stdClass;
use WP_Filesystem_Base;

/**
 * BH_WP_PSR_Logger extends this, then Logger extends that.
 *
 * @phpstan-type BackTraceFrameArray array{function: string, line?: int, file?: string, class?: class-string, type?: "->"|"::", args?: list<mixed>, object?: object}
 * @phpstan-type BackTraceArray list<BackTraceFrameArray>
 *
 * @see BH_WP_PSR_Logger
 * @see Logger
 */
class API implements API_Interface {

	use LoggerAwareTrait;

	// TODO: replace globals with `wp_cache_set()` etc.
	const CACHE_GROUP_KEY = 'bh-wp-logger';

	/**
	 *
	 * TODO: IS {@see getmypid()} reliable?
	 * TODO: Add current user id.
	 *
	 * @see https://stackoverflow.com/questions/10404979/get-unique-worker-thread-process-request-id-in-php
	 *
	 * @var array<string,mixed> Common data for context. "state"?
	 */
	protected array $common_context = array();

	/**
	 * Instantiate the API class with settings provided by the plugin.
	 *
	 * BH_WP_PSR_Logger needs and API instance and API needs a PSR logger instance if it is to log. LoggerAwareTrait
	 * allows setting the logger after instantiation.
	 *
	 * @param Logger_Settings_Interface $settings The settings provided by the plugin to instantiate the logger. Needed for the plugin slug to link correctly.
	 * @param LoggerInterface           $logger A PSR logger, presumably later a BH_WP_PSR_Logger.
	 */
	public function __construct(
		protected Logger_Settings_Interface $settings,
		LoggerInterface $logger
	) {
		$this->setLogger( $logger );
	}

	/**
	 * Array of data to add to every log entry.
	 * Resets on each new page-load (request).
	 *
	 * @return array<string, mixed>
	 */
	public function get_common_context(): array {
		return $this->common_context;
	}

	/**
	 * Set a value in the common context.
	 *
	 * @param string $key Descriptive key.
	 * @param mixed  $value Will be parsed to JSON later.
	 */
	public function set_common_context( string $key, mixed $value ): void {
		$this->common_context[ $key ] = $value;
	}

	/**
	 * Get the WordPress admin link to the log UI at a date.
	 *
	 * @param ?string $date A date string Y-m-d or null to get the most recent.
	 *
	 * @return string
	 */
	public function get_log_url( ?string $date = null ): string {

		$query_args = array(
			'page' => $this->settings->get_plugin_slug() . '-logs',
		);

		if ( ! empty( $date ) ) {
			$query_args['date'] = $date;
		}

		return admin_url( add_query_arg( $query_args, 'admin.php' ) );
	}

	/**
	 * Scan the logs files dir for the latest log file, or the log file matching the supplied date.
	 *
	 * TODO: Test the regex. It seems to be pulling in all files that match a date?
	 *
	 * @param ?string $date In 'Y-m-d' format. e.g. '2021-09-16'.
	 *
	 * @return array<string, string> Y-m-d index with path as the value.
	 */
	public function get_log_files( ?string $date = null ): array {

		// TODO: Replace WC_LOG_DIR check with the plugin_active check that is used overall.
		if ( ( $this->settings instanceof WooCommerce_Logger_Settings_Interface ) && defined( 'WC_LOG_DIR' ) && is_string( constant( 'WC_LOG_DIR' ) ) ) {

			/** @var string $log_files_dir */
			$log_files_dir = constant( 'WC_LOG_DIR' );

		} else {

			$log_files_dir = wp_normalize_path( WP_CONTENT_DIR . '/uploads/logs/' );
		}

		$files      = scandir( $log_files_dir );
		$logs_files = array();

		if ( ! empty( $files ) ) {
			foreach ( $files as $filename ) {
				if ( ! in_array( $filename, array( '.', '..' ), true ) ) {

					if ( ! is_dir( $filename ) && strstr( $filename, '.log' ) ) {

						if ( 1 === preg_match( '/^' . $this->settings->get_plugin_slug() . '-(\d{4}-\d{2}-\d{2}).*/', $filename, $regex_matches ) ) {
							$logs_files[ "{$regex_matches[1]}" ] = $log_files_dir . $filename;

							if ( ! is_null( $date ) && $regex_matches[1] === $date ) {
								$path     = $log_files_dir . $filename;
								$realpath = realpath( $path );
								return array( $date => false === $realpath ? $path : $realpath );
							}
						}
					}
				}
			}
		}

		ksort( $logs_files );

		return $logs_files;
	}

	/**
	 * Delete a specific date's log file.
	 *
	 * @param string $ymd_date The date formatted Y-m-d, e.g. 2021-09-27.
	 *
	 * @used-by Logs_Page
	 *
	 * @return array{success:bool, message?:string}
	 */
	public function delete_log( string $ymd_date ): array {

		$result = array();

		$log_file_paths_by_date = $this->get_log_files();

		if ( ! isset( $log_file_paths_by_date[ $ymd_date ] ) ) {
			$result['success'] = false;
			$message           = 'Log file not found for date: ' . $ymd_date;
			$result['message'] = $message;
			$this->logger->warning( $message );
			return $result;
		}

		wp_delete_file( $log_file_paths_by_date[ $ymd_date ] );
		$result['success'] = true;
		$message           = 'Logfile deleted at ' . $log_file_paths_by_date[ $ymd_date ];
		$result['message'] = $message;
		$this->logger->info( $message, array( 'logfile' => $log_file_paths_by_date[ $ymd_date ] ) );

		return $result;
	}

	/**
	 * Delete all logs for this plugin.
	 *
	 * @used-by Logs_Page
	 *
	 * @return array{success:bool, deleted_files:array<string>, failed_to_delete:array<string>}
	 */
	public function delete_all_logs(): array {

		$result = array();

		$deleted_files    = array();
		$failed_to_delete = array();

		$log_file_paths_by_date = $this->get_log_files();

		foreach ( $log_file_paths_by_date as $date => $log_filepath ) {
			$deleted = wp_delete_file( $log_filepath );
			if ( $deleted ) {
				$deleted_files[ $date ] = $log_filepath;
			} else {
				$failed_to_delete[ $date ] = $log_filepath;
			}
		}

		$result['deleted_files']    = $deleted_files;
		$result['failed_to_delete'] = $failed_to_delete;
		$result['success']          = empty( $failed_to_delete );

		return $result;
	}

	/**
	 * Deletes log files older than MONTH_IN_SECONDS.
	 * Deletes empty log files.
	 *
	 * TODO: Do not use for WooCommerce_Logger_Interface, because WooCommerce handles deleting logs itself.
	 *
	 * @used-by Cron::delete_old_logs()
	 */
	public function delete_old_logs(): void {

		$existing_logs = $this->get_log_files();

		foreach ( $existing_logs as $date => $log_filepath ) {

			if ( strtotime( $date ) < time() - MONTH_IN_SECONDS ) {
				$this->logger->debug( 'deleting old log file ' . $log_filepath );
				wp_delete_file( $log_filepath );
			} elseif ( 0 === filesize( $log_filepath ) ) {
				$this->logger->debug( 'deleting empty log file ' . $log_filepath );
				wp_delete_file( $log_filepath );
			}
		}

		// TODO: delete the last visited option if it's older than the most recent logs.
	}


	/**
	 * Get the backtrace and skips:
	 * * function calls from inside this file
	 * * call_user_func_array()
	 * * function calls from other plugins using this same library (using filename).
	 *
	 * @param ?string $source_hash A unique identifier for the source of the log entry. Used to cache the backtrace. The backtrace will not be cached if this is absent.
	 * @param ?int    $steps The number of backtrace entries to return.
	 *
	 * @return BackTraceArray
	 */
	public function get_backtrace( ?string $source_hash = null, ?int $steps = null ): array {

		if ( ! empty( $source_hash ) ) {
			$backtrace_cached = $this->get_cached_backtrace( $source_hash );

			if ( is_array( $backtrace_cached ) ) {
				return $backtrace_cached;
			}
		}

		/**
		 * This is critical to the library.
		 *
		 * phpcs:disable WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
		 *
		 * @var BackTraceArray $backtrace
		 */
		$backtrace = debug_backtrace();

		$ignore_starting_frame = function ( array $frame ): bool {
			/** @var BackTraceFrameArray $frame */
			switch ( true ) {
				case isset( $frame['file'] ) && __FILE__ === $frame['file']:
				case 'call_user_func_array' === $frame['function']:
				case isset( $frame['file'] ) && basename( $frame['file'] ) === 'class-php-error-handler.php':
				case isset( $frame['file'] ) && basename( $frame['file'] ) === 'class-functions.php':
				case isset( $frame['file'] ) && false !== stripos( $frame['file'], 'bh-wp-logger/includes' ):
				case isset( $frame['file'] ) && false !== stripos( $frame['file'], 'psr/log/Psr/Log/' ):
				case isset( $frame['file'] ) && str_contains( $frame['file'], 'php-http/logger-plugin' ):
					return true;
				default:
					return false;
			}
		};

		foreach ( $backtrace as $index => $frame ) {
			if ( $ignore_starting_frame( $frame ) ) {
				unset( $backtrace[ $index ] );
			} else {
				break;
			}
		}
		/** @var BackTraceArray $backtrace */

		if ( ! is_null( $source_hash ) ) {
			$this->set_cached_backtrace( $source_hash, $backtrace );
		}

		return $backtrace;
	}

	/**
	 * Save the backtrace to a global cache.
	 *
	 * @see PHP_Error_Handler::is_related_error()
	 *
	 * If other plugins are using bh-wp-logger, they can use this cache to avoid rerunning the backtrace.
	 *
	 * @see debug_backtrace()
	 *
	 * @param string               $source_hash A unique identifier for backtrace – `implode(func_get_args())` of the error handler is used.
	 * @param BackTraceArray&array $backtrace The PHP backtrace, presumably filtered to remove irrelevant frames.
	 */
	protected function set_cached_backtrace( string $source_hash, array $backtrace ): void {
		if ( ! isset( $GLOBALS['bh_wp_logger_cache'] ) || ! is_array( $GLOBALS['bh_wp_logger_cache'] ) ) {
			$GLOBALS['bh_wp_logger_cache'] = array();
		}
		$source_hash                                   = sanitize_key( $source_hash );
		$GLOBALS['bh_wp_logger_cache'][ $source_hash ] = $backtrace;
	}

	/**
	 * Check if the backtrace for this error already been run.
	 *
	 * @param string $source_hash A unique identifier for backtrace.
	 *
	 * @return ?BackTraceArray
	 */
	protected function get_cached_backtrace( string $source_hash ): ?array {
		$source_hash = sanitize_key( $source_hash );

		if ( ! isset( $GLOBALS['bh_wp_logger_cache'] ) ) {
			return null;
		}

		/** @var array<string, BackTraceArray> $bh_wp_logger_cache */
		global $bh_wp_logger_cache;

		return $bh_wp_logger_cache[ $source_hash ] ?? null;
	}

	/**
	 * Checks each file in the backtrace and if it contains WP_PLUGINS_DIR/plugin-slug then return true.
	 *
	 * @param ?string $source_hash A unique identifier for the source of the log entry.
	 */
	public function is_backtrace_contains_plugin( ?string $source_hash = null ): bool {

		$frames = $this->get_backtrace( $source_hash );

		$is_file_from_plugin = false;

		foreach ( $frames as $frame ) {

			if ( isset( $frame['file'] ) && $this->is_file_from_plugin( $frame['file'] ) ) {
				$is_file_from_plugin = true;
				break;
			}
		}

		return $is_file_from_plugin;
	}

	/**
	 * Given a filepath, tries to determine if this file is part of this plugin.
	 *
	 * TODO: Be consistent about meanings of plugin-slug and plugin basename.
	 * TODO: Remove code duplication with Plugins class.
	 *
	 * @see Plugins::get_plugin_data_from_slug()
	 *
	 * @param string $filepath Path to the file to be checked.
	 */
	public function is_file_from_plugin( string $filepath ): bool {
		return str_starts_with( plugin_basename( realpath( $filepath ) ?: $filepath ), $this->settings->get_plugin_slug() );
	}

	/**
	 * Get the name of the plugin-specific transient which indicates the last log message time.
	 *
	 * The value is used on plugins.php to show if new logs have been recorded.
	 * A transient is used to avoid re-calculating it from reading the log files from disk.
	 *
	 * @return string
	 */
	public function get_last_log_time_transient_name(): string {
		return $this->settings->get_plugin_slug() . '-last-log-time';
	}

	/**
	 * Used on plugins.php to highlight the logs link if there are new logs since they were last viewed.
	 *
	 * Saves the time in a 24-hour transient to avoid filesystem calls. The transient is deleted when the log is written to.
	 */
	public function get_last_log_time(): ?DateTimeInterface {

		// If a user can't access `plugins.php`, this method is moot.
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return null;
		}

		$transient_name = $this->get_last_log_time_transient_name();

		$transient_value = get_transient( $transient_name );

		if ( is_string( $transient_value ) ) {
			try {
				return new DateTimeImmutable( $transient_value, new DateTimeZone( 'UTC' ) );
			} catch ( Exception $_exception ) {
				delete_transient( $transient_name );
			}
		}

		$log_files = $this->get_log_files();

		$reverse_chronological_log_files = array_reverse( $log_files );

		if ( empty( $GLOBALS['wp_filesystem'] ) ) {
			WP_Filesystem();
		}

		/** @var WP_Filesystem_Base $wp_filesystem */
		global $wp_filesystem;

		foreach ( $reverse_chronological_log_files as $last_log_file_path ) {

			if ( ! $wp_filesystem->exists( $last_log_file_path ) ) {
				continue;
			}

			$timestamp = $wp_filesystem->mtime( $last_log_file_path );

			if ( ! is_numeric( $timestamp ) ) {
				continue;
			}

			$datetime = new DateTimeImmutable( "@{$timestamp}" );

			set_transient( $transient_name, $datetime->format( DateTimeInterface::ATOM ), constant( 'DAY_IN_SECONDS' ) );

			// Log time will always be UTC.
			return $datetime;
		}

		return null;
	}

	/**
	 * Used on plugins.php to highlight the logs link if there are new logs since they were last viewed.
	 *
	 * @return ?DateTimeInterface
	 */
	public function get_last_logs_view_time(): ?DateTimeInterface {

		$option_name                    = $this->settings->get_plugin_slug() . '-last-logs-view-time';
		$last_log_view_time_atom_string = get_option( $option_name );

		if ( ! is_string( $last_log_view_time_atom_string ) ) {
			if ( ! empty( $last_log_view_time_atom_string ) ) {
				delete_option( $option_name );
			}
			return null;
		}

		$last_log_view_time_datetime = DateTimeImmutable::createFromFormat( DateTimeInterface::ATOM, $last_log_view_time_atom_string, new DateTimeZone( 'UTC' ) );

		if ( false === $last_log_view_time_datetime ) {
			delete_option( $option_name );
			return null;
		}

		return $last_log_view_time_datetime;
	}

	/**
	 * Record the last time the logs were viewed in order to determine if admin notices should or should not be displayed.
	 * i.e. "mark read".
	 *
	 * @used-by Logs_Page
	 *
	 * @param ?DateTimeInterface $date_time A time to set, defaults to "now".
	 *
	 * phpcs:disable Generic.CodeAnalysis.EmptyStatement.DetectedCatch
	 */
	public function set_last_logs_view_time( ?DateTimeInterface $date_time = null ): void {
		$option_name = $this->settings->get_plugin_slug() . '-last-logs-view-time';

		try {
			$date_time ??= new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		} catch ( Exception $_exception ) { /** @phpstan-ignore catch.neverThrown */
			/**
			 * This will never happen.
			 */
			return;
		}

		$atom_time_string = $date_time->format( DateTimeInterface::ATOM );

		update_option( $option_name, $atom_time_string );
	}

	/**
	 * Given the path to a log file, this returns an array of arrays – an array of log entries, each of which is an
	 * array containing the time, level, message and context.
	 *
	 * @used-by API::get_last_log_time()
	 * @used-by Logs_List_Table::get_data()
	 *
	 * @param string $filepath Path to the log file to read.
	 *
	 * @return array<array{time:string,datetime:DateTime|null,level:string,message:string,context:stdClass|null}>
	 */
	public function parse_log( string $filepath ): array {

		// The file is read one line at a time to avoid loading a potentially large log into memory.
		$file_handle = fopen( $filepath, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( false === $file_handle ) {
			// Failed to open the file.
			return array();
		}

		if ( $this->logger instanceof WC_PSR_Logger ) {
			$pattern = '/^(?P<time>[^\s]*)\s(?P<level>\w*)\s(?P<message>.*?)\sCONTEXT:\s(?P<context>.*)/';
		} else {
			$pattern = '/(?P<time>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.{1}\d{2}:\d{2})\s(?P<level>\w*)\s(?P<message>.*)/im';
		}

		$time_pattern = '/^(?P<time>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.{1}\d{2}:\d{2})/i';

		$entries = array();

		/**
		 * Each log entry begins with a line starting with a timestamp ($time_pattern). Read the file
		 * one line at a time, accumulating the lines of the current entry until the next timestamped
		 * line (or the end of the file), then hand the collected lines off to be parsed into a single
		 * entry. Lines before the first timestamp do not belong to any entry and are discarded.
		 */
		$entry_lines = array();

		while ( false !== ( $line = fgets( $file_handle ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition

			$line = rtrim( $line, "\r\n" );

			if ( 1 === preg_match( $time_pattern, $line ) ) {
				// A new entry starts on this line; parse the entry that just ended.
				if ( count( $entry_lines ) > 0 ) {
					$entry = $this->log_lines_to_entry( $entry_lines, $pattern );
					if ( ! is_null( $entry ) ) {
						$entries[] = $entry;
					}
				}
				$entry_lines = array( $line );
			} elseif ( count( $entry_lines ) > 0 ) {
				// A continuation line, e.g. a stack trace or multi-line JSON context.
				$entry_lines[] = $line;
			}
		}

		// Parse the final entry.
		if ( count( $entry_lines ) > 0 ) {
			$entry = $this->log_lines_to_entry( $entry_lines, $pattern );
			if ( ! is_null( $entry ) ) {
				$entries[] = $entry;
			}
		}

		return $entries;
	}

	/**
	 * Given the lines that make up a single log entry, parse them into the time, level, message and context.
	 *
	 * The first line contains the time, level and message (and, for WooCommerce, an inline context). Any
	 * remaining lines are a continuation of the message (e.g. a stack trace) followed by the JSON context.
	 * To recover the context: if the entry ends with `}`, seek in reverse for the line that opens the JSON
	 * object, decode from there to the end, and treat the lines before it as the remainder of the message.
	 *
	 * @used-by API::parse_log()
	 *
	 * @param string[] $lines   The lines of a single log entry, with newlines already stripped.
	 * @param string   $pattern The regex used to parse the first line into time/level/message (and, for WooCommerce, an inline context).
	 *
	 * @return ?array{time:string,datetime:DateTime|null,level:string,message:string,context:stdClass|null}
	 */
	protected function log_lines_to_entry( array $lines, string $pattern ): ?array {

		$line_one = array();
		if ( 1 !== preg_match( $pattern, $lines[0], $line_one ) ) {
			// The first line does not match the expected format; skip this entry.
			return null;
		}

		$time_string = $line_one['time'];
		$str_time    = strtotime( $time_string );
		// E.g. "2020-10-23T17:39:36+00:00".
		$datetime = DateTime::createFromFormat( 'U', "{$str_time}" ) ?: null;

		$level   = $line_one['level'];
		$message = $line_one['message'];
		$context = null;

		if ( isset( $line_one['context'] ) ) {

			// WooCommerce logs the context inline on the first line, after "CONTEXT:".
			$context = json_decode( $line_one['context'] );

		} else {

			$context_lines = array_slice( $lines, 1 );

			// If the entry ends with `}`, the JSON context is the block from the last line that opens
			// with `{` to the end. Seek in reverse for that line and attempt to decode from it.
			if ( count( $context_lines ) > 0 && str_ends_with( end( $context_lines ), '}' ) ) {

				for ( $i = count( $context_lines ) - 1; $i >= 0; $i-- ) {
					if ( str_starts_with( ltrim( $context_lines[ $i ] ), '{' ) ) {
						break;
					}
				}

				if ( $i >= 0 ) {
					$candidate = implode( "\n", array_slice( $context_lines, $i ) );

					// The context can contain unescaped literal newlines inside string values (e.g. a
					// stack trace), which json_decode rejects; escape them and try again.
					$context = json_decode( $candidate ) ?? json_decode( str_replace( "\n", '\n', $candidate ) );

					if ( ! is_null( $context ) ) {
						// Any lines before the JSON object are a continuation of the message.
						$message_lines = array_slice( $context_lines, 0, $i );
						if ( count( $message_lines ) > 0 ) {
							$message = rtrim( $message . "\n" . implode( "\n", $message_lines ) );
						}
						$context_lines = array();
					}
				}
			}

			// Fallback: any remaining lines that are not themselves valid JSON are message text.
			if ( is_null( $context ) ) {
				foreach ( $context_lines as $context_line ) {
					$decoded = json_decode( $context_line );
					if ( is_null( $decoded ) ) {
						$message .= "\n" . $context_line;
					} else {
						$context = $decoded;
					}
				}
			}
		}

		if ( $context instanceof stdClass && isset( $context->source ) ) {
			unset( $context->source );
		}

		return array(
			'time'     => $time_string,
			'datetime' => $datetime,
			'level'    => $level,
			'message'  => $message,
			'context'  => $context instanceof stdClass ? $context : null,
		);
	}
}
