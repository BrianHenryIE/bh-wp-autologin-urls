<?php
/**
 * Add the hooks to WordPress.
 *
 * @package    brianhenryie/bh-wp-private-uploads
 */

namespace BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads;

use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\Admin\Admin_Assets;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\Admin\Admin_Menu;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\Admin\Admin_Meta_Boxes;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\Admin\Admin_Notices;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\API\Media_Request;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\Frontend\Serve_Private_File;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\CLI;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\Cron;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\Media;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\Post_Type;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\Upload;
use BrianHenryIE\WP_Autologin_URLs\WP_Private_Uploads\WP_Includes\WP_Rewrite;
use BrianHenryIE\WP_Autologin_URLs\Psr\Log\LoggerInterface;

/**
 * Exclusively `add_action()` and `add_filter()` preceded with conditional checks.
 */
class BH_WP_Private_Uploads_Hooks {

	/**
	 * Constructor
	 *
	 * @param API_Interface                      $api The main functions.
	 * @param Private_Uploads_Settings_Interface $settings The configured settings.
	 * @param LoggerInterface                    $logger PSR logger to record errors.
	 *
	 * @since    1.0.0
	 */
	public function __construct(
		protected API_Interface $api,
		protected Private_Uploads_Settings_Interface $settings,
		protected LoggerInterface $logger
	) {
		$this->define_api_hooks();
		$this->define_admin_notices_hooks();
		$this->define_frontend_hooks();
		$this->define_cron_job_hooks();
		$this->define_cli_hooks();
		$this->define_post_hooks();
		$this->define_rewrite_hooks();

		$this->define_meta_box_hooks();
		$this->define_media_library_hooks();

		$this->define_admin_menu_hooks();
	}

	/**
	 * On every load, ensure the directory exists.
	 *
	 * The closure discards the `Create_Directory_Result` – action callbacks return nothing. The result is
	 * only of interest to direct callers; `create_directory()` logs its own failures.
	 *
	 * TODO: Think about how this could be delayed. Let's avoid file-system operations unless 100% necessary.
	 */
	protected function define_api_hooks(): void {
		add_action(
			'init',
			function (): void {
				$this->api->create_directory();
			}
		);
	}

	/**
	 * Maybe register the post type.
	 */
	protected function define_post_hooks(): void {

		if ( empty( $this->settings->get_post_type_name() ) ) {
			return;
		}

		$post = new Post_Type( $this->settings );

		add_action( 'init', array( $post, 'register_post_type' ) );
	}

	/**
	 * Register hooks for handling admin notices: display and dismissal.
	 */
	protected function define_admin_notices_hooks(): void {

		$admin_notices = new Admin_Notices( $this->api, $this->settings, $this->logger );

		// Generate the notices from wp_options.
		add_action( 'admin_init', array( $admin_notices, 'admin_notices' ), 9 );
		// Add the notice.
		add_action( 'admin_notices', array( $admin_notices, 'the_notices' ) );

		// When the "publicly accessible" notice is dismissed, schedule a cron job to un-snooze it after a week.
		// `add_option_{$option}` fires with `( $option, $value )`; `update_option_{$option}` with `( $old_value, $value, $option )`.
		$option_name = ( new Cron( $this->api, $this->settings, $this->logger ) )->get_dismissed_notice_option_name();
		add_action( "add_option_{$option_name}", array( $admin_notices, 'on_dismiss' ), 10, 2 );
		add_action( "update_option_{$option_name}", array( $admin_notices, 'on_dismiss' ), 10, 3 );
	}

	/**
	 * Register hooks for handling frontend delivery of the files.
	 */
	protected function define_frontend_hooks(): void {

		$serve_private_file = new Serve_Private_File( $this->settings, $this->logger );

		add_action( 'init', array( $serve_private_file, 'init' ) );
	}

	/**
	 * Define hooks for a cron job to regularly check the folder is private.
	 */
	protected function define_cron_job_hooks(): void {

		// TODO: only run this on cron jobs to avoid unnecessary work on every `init`.

		$cron = new Cron( $this->api, $this->settings, $this->logger );

		add_action( 'init', array( $cron, 'register_cron_job' ) );

		add_action( $cron->get_check_url_cron_hook_name(), array( $cron, 'check_is_url_public' ) );

		add_action( $cron->get_unsnooze_notice_cron_hook_name(), array( $cron, 'unsnooze_dismissed_notice' ) );
	}

	/**
	 * Register CLI commands: `download`.
	 */
	protected function define_cli_hooks(): void {

		if ( is_null( $this->settings->get_cli_base() ) ) {
			return;
		}

		$cli = new CLI( $this->api, $this->settings, $this->logger );

		add_action( 'cli_init', array( $cli, 'register_commands' ) );
	}

	/**
	 * Define hooks for adding .htaccess rules to make the folder private.
	 */
	protected function define_rewrite_hooks(): void {

		$rewrite = new WP_Rewrite( $this->settings, $this->logger );

		add_action( 'init', array( $rewrite, 'register_rewrite_rule' ) );
	}

	/**
	 * Define hooks which redirect attachments uploaded through the media library to the private uploads directory.
	 */
	protected function define_media_library_hooks(): void {

		if ( ! is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		$media_request = new Media_Request();

		$media = new Media( $this->settings, $media_request );

		add_action( 'wp_ajax_query-attachments', array( $media, 'on_query_attachments' ), 1 );
		add_action( 'admin_init', array( $media, 'on_upload_attachment' ), 1 );

		$admin_assets = new Admin_Assets( $this->settings );

		add_action( 'admin_init', array( $admin_assets, 'register_script' ), 1 );

		if ( ! $media_request->is_relevant_page() ) {
			return;
		}

		$post_type = $this->settings->get_post_type_name();

		if ( ! $media_request->request_uri_has_post_type( $post_type )
			&& ! $media_request->referer_uri_has_post_type( $post_type ) ) {
			return;
		}

		$upload = new Upload( $this->settings, $media_request );

		add_action( 'current_screen', array( $upload, 'current_screen' ) );
		add_filter( 'query', array( $upload, 'replace_post_type_in_query' ) );
		add_action( 'wp', array( $upload, 'wp' ) );
		add_action( 'pre_get_posts', array( $upload, 'pre_get_posts' ) );
		add_filter( 'the_posts', array( $upload, 'the_posts' ), 10, 2 );
		add_filter( 'clean_url', array( $upload, 'clean_url' ) );
		add_action( 'admin_init', array( $upload, 'admin_init' ) );
		add_filter( 'manage_upload_columns', array( $upload, 'manage_upload_columns' ) );
	}

	/**
	 * When `Settings::get_meta_box_settings()` has an array (key:value post_type:meta-box-args), display the
	 * upload meta-box on the post type.
	 */
	protected function define_meta_box_hooks(): void {
		$admin_meta_boxes = new Admin_Meta_Boxes( $this->settings, $this->logger );

		add_action( 'add_meta_boxes', array( $admin_meta_boxes, 'add_meta_box' ), 10, 2 );
	}

	/**
	 * If `show_in_menu` is set, add a submenu to "Media" for the new post type.
	 */
	protected function define_admin_menu_hooks(): void {

		$admin_menu_hooks = new Admin_Menu( $this->settings );

		// This needs to run first for the other hooks to have any real effect.
		add_action( 'registered_post_type', array( $admin_menu_hooks, 'get_registered_post_type_object' ), 10, 2 );

		add_action( 'admin_menu', array( $admin_menu_hooks, 'add_private_media_library_menu' ) );
		add_filter( 'submenu_file', array( $admin_menu_hooks, 'highlight_menu' ), 10, 2 );
		add_action( 'admin_menu', array( $admin_menu_hooks, 'remove_top_level_menu' ), 1000 );
	}
}
