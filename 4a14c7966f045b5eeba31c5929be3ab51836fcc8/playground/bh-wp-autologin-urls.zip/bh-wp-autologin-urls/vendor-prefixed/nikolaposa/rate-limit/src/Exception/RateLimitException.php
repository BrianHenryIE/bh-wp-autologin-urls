<?php

declare(strict_types=1);

namespace BrianHenryIE\WP_Autologin_URLs\RateLimit\Exception;

use Throwable;

interface RateLimitException extends Throwable
{
}
