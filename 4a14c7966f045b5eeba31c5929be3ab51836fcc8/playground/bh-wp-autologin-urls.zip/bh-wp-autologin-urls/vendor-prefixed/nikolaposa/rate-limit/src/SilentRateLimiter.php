<?php

declare(strict_types=1);

namespace BrianHenryIE\WP_Autologin_URLs\RateLimit;

interface SilentRateLimiter
{
    public function limitSilently(string $identifier): Status;
}
