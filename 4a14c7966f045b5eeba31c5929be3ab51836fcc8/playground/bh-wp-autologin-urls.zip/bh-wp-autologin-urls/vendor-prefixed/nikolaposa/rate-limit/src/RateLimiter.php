<?php

declare(strict_types=1);

namespace BrianHenryIE\WP_Autologin_URLs\RateLimit;

use BrianHenryIE\WP_Autologin_URLs\RateLimit\Exception\LimitExceeded;

interface RateLimiter
{
    /**
     * @throws LimitExceeded
     */
    public function limit(string $identifier): void;
}
