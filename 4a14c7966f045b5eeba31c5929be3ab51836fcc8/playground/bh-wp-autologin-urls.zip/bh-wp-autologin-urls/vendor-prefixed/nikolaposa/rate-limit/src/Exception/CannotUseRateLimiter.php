<?php

declare(strict_types=1);

namespace BrianHenryIE\WP_Autologin_URLs\RateLimit\Exception;

use RuntimeException;

final class CannotUseRateLimiter extends RuntimeException implements RateLimitException
{
}
