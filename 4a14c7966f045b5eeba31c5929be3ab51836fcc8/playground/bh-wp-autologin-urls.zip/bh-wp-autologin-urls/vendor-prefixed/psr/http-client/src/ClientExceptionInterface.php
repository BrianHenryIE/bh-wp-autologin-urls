<?php

namespace BrianHenryIE\WP_Autologin_URLs\Psr\Http\Client;

/**
 * Every HTTP client related exception MUST implement this interface.
 */
interface ClientExceptionInterface extends \Throwable
{
}
