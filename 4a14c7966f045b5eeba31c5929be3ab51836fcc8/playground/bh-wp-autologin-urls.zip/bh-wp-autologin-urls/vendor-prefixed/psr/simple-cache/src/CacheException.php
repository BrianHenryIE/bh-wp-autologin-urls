<?php

namespace BrianHenryIE\WP_Autologin_URLs\Psr\SimpleCache;

/**
 * Interface used for all types of exceptions thrown by the implementing library.
 */
interface CacheException
{
}
