<?php

namespace BrianHenryIE\WP_Autologin_URLs\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
