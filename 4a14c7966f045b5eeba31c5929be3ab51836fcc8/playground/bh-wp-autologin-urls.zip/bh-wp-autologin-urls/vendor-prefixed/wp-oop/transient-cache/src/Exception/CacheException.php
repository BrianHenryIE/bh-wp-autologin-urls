<?php

declare(strict_types=1);

namespace BrianHenryIE\WP_Autologin_URLs\WpOop\TransientCache\Exception;

use Exception;
use BrianHenryIE\WP_Autologin_URLs\Psr\SimpleCache\CacheException as CacheExceptionInterface;

/**
 * @inheritDoc
 */
class CacheException extends Exception implements CacheExceptionInterface
{
}
