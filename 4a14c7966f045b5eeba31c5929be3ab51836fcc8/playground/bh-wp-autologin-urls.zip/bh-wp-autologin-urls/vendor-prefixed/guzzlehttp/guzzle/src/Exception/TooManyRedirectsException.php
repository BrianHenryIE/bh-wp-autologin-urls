<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
