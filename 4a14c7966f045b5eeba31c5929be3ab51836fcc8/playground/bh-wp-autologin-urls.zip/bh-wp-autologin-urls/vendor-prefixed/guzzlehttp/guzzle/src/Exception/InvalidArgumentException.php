<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
