<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp;

use BrianHenryIE\WP_Autologin_URLs\Psr\Http\Message\MessageInterface;

interface BodySummarizerInterface
{
    /**
     * Returns a summarized message body.
     */
    public function summarize(MessageInterface $message): ?string;
}
