<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

/**
 * Exception when a client error is encountered (4xx codes)
 */
class ClientException extends BadResponseException
{
}
