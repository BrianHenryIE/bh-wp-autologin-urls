<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends BadResponseException
{
}
