<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
