<?php

namespace BrianHenryIE\WP_Autologin_URLs\GuzzleHttp\Exception;

use BrianHenryIE\WP_Autologin_URLs\Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
